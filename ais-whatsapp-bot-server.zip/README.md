# AIS WhatsApp FAQ Bot — Deployment Guide

This server connects your WhatsApp Business number to Claude AI so customers get instant, intelligent replies 24/7.

---

## What You Need Before Starting

- [ ] Meta Business Account (business.facebook.com)
- [ ] WhatsApp Business API number (set up in Meta Developer dashboard)
- [ ] Anthropic API key (console.anthropic.com)
- [ ] GitHub account (free)
- [ ] Railway account (railway.app — free tier works)

Total setup time: ~45 minutes

---

## Step 1 — Push Code to GitHub

1. Go to github.com → New repository → name it `ais-whatsapp-bot`
2. Upload these 3 files: `index.js`, `package.json`, `.env.example`
3. Do NOT upload any `.env` file with real keys

---

## Step 2 — Deploy to Railway

1. Go to railway.app → New Project → Deploy from GitHub
2. Select your `ais-whatsapp-bot` repo
3. Railway auto-detects Node.js and deploys it
4. Go to **Variables** tab and add these 4 environment variables:

```
VERIFY_TOKEN      = ais_webhook_secret_2024   (or any string you choose)
WHATSAPP_TOKEN    = [from Meta dashboard]
WHATSAPP_PHONE_ID = [from Meta dashboard]
ANTHROPIC_API_KEY = [from Anthropic console]
```

5. Go to **Settings → Networking** → Generate Domain
6. Copy your Railway URL (e.g. `https://ais-bot-production.up.railway.app`)

---

## Step 3 — Get Your Meta Credentials

1. Go to developers.facebook.com → My Apps → Create App → Business
2. Add **WhatsApp** product
3. Under **API Setup**, note:
   - **Phone Number ID** → goes into `WHATSAPP_PHONE_ID`
   - **Temporary Access Token** → goes into `WHATSAPP_TOKEN` (for testing)
   - For production, generate a **Permanent Token** via System User in Business Manager

---

## Step 4 — Connect Webhook to Meta

1. In Meta Developer dashboard → WhatsApp → Configuration → Webhooks
2. Click **Edit**
3. Set **Callback URL** to: `https://your-railway-url.up.railway.app/webhook`
4. Set **Verify Token** to whatever you put in `VERIFY_TOKEN`
5. Click **Verify and Save**
6. Subscribe to the **messages** field

✅ If it says "Verified" — you're connected.

---

## Step 5 — Test It

1. In Meta dashboard → WhatsApp → API Setup → send a test message to your WhatsApp number
2. Or just WhatsApp your business number from your phone
3. You should get a reply from Claude within 2-3 seconds

---

## How the Bot Works

```
Customer sends WhatsApp message
        ↓
Meta sends it to your Railway webhook (/webhook POST)
        ↓
Server sends message + conversation history to Claude API
        ↓
Claude replies using the AIS system prompt
        ↓
Server sends Claude's reply back to the customer via WhatsApp
```

The bot remembers the last 10 back-and-forths per customer (in memory). If the server restarts, history resets — that's fine for an FAQ bot.

---

## Updating the Bot's Knowledge

To change what the bot knows or how it responds, edit the `SYSTEM_PROMPT` section in `index.js`. You can add:
- Client-specific FAQs
- Pricing information
- Your contact details
- Business hours

Then push to GitHub — Railway auto-redeploys in ~60 seconds.

---

## Costs

| Service | Cost |
|---|---|
| Railway hosting | Free (500hrs/month) or $5/month for always-on |
| Claude API | ~$0.003 per conversation (very cheap) |
| Meta WhatsApp API | Free up to 1,000 conversations/month |

For a small business doing under 1,000 WhatsApp conversations/month, this runs at essentially **$0**.
